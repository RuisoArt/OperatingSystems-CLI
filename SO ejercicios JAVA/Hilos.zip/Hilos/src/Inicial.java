import java.io.File;


public class Inicial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File archivo = new File ("E:\\prueba.txt");
		
		for (int i = 0; i < 10 ; i++) 
		{
			Hilo hilohijo = new Hilo("Hilo"+i);
			hilohijo.start();
		}
		
	}

}
