import java.io.FileWriter;
import java.io.PrintWriter;



public class Hilo extends Thread{
	
		private String cadena;
		
		
	
		public Hilo(String cadena) {
			super();
			this.cadena = cadena;
		}

		public void run()
		{
			FileWriter fichero = null;
	        PrintWriter pw = null;
	        try
	        {
	            fichero = new FileWriter("E:/prueba.txt", true);
	            pw = new PrintWriter(fichero);

	            for (int i = 0; i < 10; i++)
	                pw.println("Linea " + i + "hilo: "+this.getId()+" : "+cadena);

	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	           try {
	           // Nuevamente aprovechamos el finally para 
	           // asegurarnos que se cierra el fichero.
	           if (null != fichero)
	              fichero.close();
	           } catch (Exception e2) {
	              e2.printStackTrace();
	           }
	        }
		}

}
